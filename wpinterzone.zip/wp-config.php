<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u572999072_izstorage' );

/** MySQL database username */
define( 'DB_USER', 'u572999072_izstorage' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Mil890823@' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'U.kpMu|,3f@A|A~.=!rSv24+mF:sLQfJ94f;4r6}%ss9q9ah0{?^xfN:[ISkBtR$' );
define( 'SECURE_AUTH_KEY',  't?hetK+?d,l0B>x<0Yj8A2aUBE-SV^l|~QlHc_~9IL8uxT8ZUZw%k1IK:JawMSVQ' );
define( 'LOGGED_IN_KEY',    '2a<1Je@a hp=PZ6)Aq]4z`+a?[m.A6TKXzL]N!Ed>m4#]mBsk>+qcm=FE$9,/_:n' );
define( 'NONCE_KEY',        'O@-Gee|n_ZyECvW?e{=&.(UG0fEXiU7=eZT4IvzepEF_Hvrf@C{]}ITDr`6--r9a' );
define( 'AUTH_SALT',        'r{9<<FcP_5v:w4=y-3CJ.(AJn6Hf[136py|b#yhX,p)KP5$6^f(e3.JG5e;{s BH' );
define( 'SECURE_AUTH_SALT', 'JJr1Uo)Q3Q_y?ea@@-?XG/Q{y0I b@tgDjC;XeP{fEB9:0#rs^@CK];`8J5%>P@$' );
define( 'LOGGED_IN_SALT',   'n>XS@0]0FlK$xfk=Wqg`r!~Cw0wf]8tsg%eZd5x7<%+&d~mjC _@f%7.@?_l$/ae' );
define( 'NONCE_SALT',       'Z5.c4+Aq&J/`wpO@[i?1@/sS5;{09qqDE ?!&cf}<eGNFI#Q/A/gtK0o8<E63(9|' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'izweb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
